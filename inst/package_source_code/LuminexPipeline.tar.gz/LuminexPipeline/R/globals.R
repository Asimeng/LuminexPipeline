utils::globalVariables(c("dir_main", "txt", "header_repeat"))
                      # , "tech_reps","config_isa", "isa_path", "analyte_reference_path",
                       #  "dir_md5sum","dir_data"))
utils::globalVariables(c("dta","d","filename","kit","instrument","plate","rerun"))
